use centennial;

create table customers(customerId int primary key,userName varchar(30),password varchar(30),firstname varchar(30),lastname varchar(30),
address varchar(30),city varchar(30),postalCode varchar(30) );

create table products(productId int primary key,productName varchar(30),price double,category varchar(20));
		 
create table orders(orderId int PRIMARY KEY,customerId int NOT NULL,productId int NOT NULL,
orderDate varchar(40),status varchar(10),amountPaid varchar(20),quantity int,category varchar(30),
foreign key (customerId) REFERENCES customers(customerId),foreign key(productId) REFERENCES products(productId));


insert into products (productId,productName,price,category) values(1,'HP',899.90,'Laptop');
insert into products (productId,productName,price,category) values(12,'APPLE',780,'Mobile');

select * from products;
