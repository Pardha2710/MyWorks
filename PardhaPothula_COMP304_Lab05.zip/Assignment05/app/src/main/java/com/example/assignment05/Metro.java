package com.example.assignment05;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Metro extends AppCompatActivity {

    double latitude=0 , longitude=0;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metro);

        List<String> dataList = new ArrayList<String>();
        dataList.add("Toronto downtown");
        dataList.add("Scarborough");
        dataList.add("Mississauga");
        dataList.add("Oakville");


        ListView listView = (ListView)findViewById(R.id.listv);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_selectable_list_item, dataList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> adapterView, View view, int index, long l) {
                Object clickItemObj = adapterView.getAdapter().getItem(index);
                if(index==0)
                {
                    // latitude=43.6543  ,  longitude=79.3860

                    latitude=43.6543 ; longitude=79.3860;
                    name="Toronto Metro";
                    Intent intent=new Intent(Metro.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",name);

                    startActivity(intent);
                }
                else if(index==1)
                {
                    //latitude=43.7764 , longitude=79.2318

                    latitude=43.7764 ; longitude=79.2318;
                    name="Scarborough Metro";
                    Intent intent=new Intent(Metro.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",name);

                    startActivity(intent);
                }
                else if(index==2)
                {
                    //latitude=43.5890 , longitude=79.6441

                    latitude=43.5890 ; longitude=79.6441;
                    name="Mississauga Metro";
                    Intent intent=new Intent(Metro.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",name);

                    startActivity(intent);
                }
                else if(index==3)
                {
                    //latitude=43.4675 , longitude=79.6877

                    latitude=43.4675 ; longitude=79.6877;
                    name="Oakville Metro";
                    Intent intent=new Intent(Metro.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",name);

                    startActivity(intent);
                }

            }
        });
    }
}
