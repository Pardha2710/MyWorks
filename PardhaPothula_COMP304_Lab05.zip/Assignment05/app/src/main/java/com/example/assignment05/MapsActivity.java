package com.example.assignment05;


import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private GoogleMap gMap;
    RadioButton r1,r2;
    double latitude = 0, longitude = 0;
    String name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
//        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
//                .findFragmentById(R.id.map);
//        mapFragment.getMapAsync(this);

        latitude = getIntent().getIntExtra("latitude", 0);
        longitude = getIntent().getIntExtra("longitude", 0);
        name = getIntent().getStringExtra("name");

        final Geocoder coder = new Geocoder(getApplicationContext());


        String placeName = name;
        try {
            List<Address> geocodeResults = coder.getFromLocationName(placeName, 3);
            Iterator<Address> locations = geocodeResults.iterator();

            String locInfo = "Results:\n";

            while (locations.hasNext()) {
                Address loc = locations.next();
                locInfo += String.format("Location: %f, %f\n", loc.getLatitude(), loc.getLongitude());

                latitude = loc.getLatitude();
                longitude = loc.getLongitude();

                String pName = loc.getLocality();
                String featureName = loc.getFeatureName();
                String country = loc.getCountryName();
                String road = loc.getThoroughfare();
                locInfo += String.format("\n[%s][%s][%s][%s]", pName, featureName, road, country);
                int addIdx = loc.getMaxAddressLineIndex();
                for (int idx = 0; idx <= addIdx; idx++) {
                    String addLine = loc.getAddressLine(idx);
                    locInfo += String.format("\nLine %d: %s", idx, addLine);
                }

                SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.map);
                mapFragment.getMapAsync(this);

            }


        }
        catch (IOException e) {
            Log.e("GeoAddress", "Failed to get location info", e);
        }



    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        gMap = googleMap;

        //satellite view
        gMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);

        // Add a marker in Toronto and move the camera
        LatLng city = new LatLng(latitude, longitude);
        gMap.addMarker(new MarkerOptions().position(city).title("Marker in "+name));

        //gMap.moveCamera(CameraUpdateFactory.newLatLng(city));

        // Move the camera instantly to toronto with a zoom of 5.
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(city, 15));

    }

    public void mapchange(View view) {
        r1=(RadioButton)(findViewById(R.id.reg));
        r2=(RadioButton)(findViewById(R.id.sat));
        if(r2.isChecked())
        {
            gMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);

        }
        else{
            gMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        }
    }
}
