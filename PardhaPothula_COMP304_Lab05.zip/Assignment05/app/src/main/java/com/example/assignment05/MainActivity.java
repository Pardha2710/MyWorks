package com.example.assignment05;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<String> dataList = new ArrayList<String>();
        dataList.add("Freshco");
        dataList.add("Metro");
        dataList.add("Nofrills");
        dataList.add("Food Basics");


        ListView listView = (ListView)findViewById(R.id.listv);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_selectable_list_item, dataList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> adapterView, View view, int index, long l) {
                Object clickItemObj = adapterView.getAdapter().getItem(index);
                if(index==0)
                {
                    Intent intent=new Intent(MainActivity.this, Freshco.class);
                    startActivity(intent);
                }
                else if(index==1)
                {
                    Intent intent=new Intent(MainActivity.this, Metro.class);
                    startActivity(intent);
                }
                else if(index==2)
                {
                    Intent intent=new Intent(MainActivity.this, Nofrills.class);
                    startActivity(intent);
                }
                else if(index==3)
                {
                    Intent intent=new Intent(MainActivity.this, FoodBasics.class);
                    startActivity(intent);
                }



            }
        });
    }
}
