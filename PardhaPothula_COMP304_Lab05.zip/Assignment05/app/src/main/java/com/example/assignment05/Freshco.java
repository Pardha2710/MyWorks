package com.example.assignment05;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class Freshco extends AppCompatActivity {

    double latitude=0 , longitude=0;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freshco);


        List<String> dataList = new ArrayList<String>();
        dataList.add("Toronto");
        dataList.add("Scarborough");
        dataList.add("Mississauga");
        dataList.add("Oakville");


        ListView listView = (ListView)findViewById(R.id.listv);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_selectable_list_item, dataList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> adapterView, View view, int index, long l) {
                Object clickItemObj = adapterView.getAdapter().getItem(index);
                if(index==0)
                {
                    // latitude=43.6543  ,  longitude=79.3860

                    latitude=43.6543 ; longitude=79.3860;
                    name="Toronto Freshco";
                    Intent intent=new Intent(Freshco.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",name);

                    intent.putExtra("fresh",R.drawable.freshco);

                    startActivity(intent);
                }
                else if(index==1)
                {
                    //latitude=43.7764 , longitude=79.2318

                    latitude=43.7764 ; longitude=79.2318;
                    name="Scarborough Freshco";
                    Intent intent=new Intent(Freshco.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",name);

                    startActivity(intent);
                }
                else if(index==2)
                {
                    //latitude=43.5890 , longitude=79.6441

                    latitude=43.5890 ; longitude=79.6441;
                    name="Mississauga Freshco";
                    Intent intent=new Intent(Freshco.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",name);

                    startActivity(intent);
                }
                else if(index==3)
                {
                    //latitude=43.4675 , longitude=79.6877

                    latitude=43.4675 ; longitude=79.6877;
                    name="Oakville Freshco";
                    Intent intent=new Intent(Freshco.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",name);
                    startActivity(intent);
                }
            }
        });
    }
}
