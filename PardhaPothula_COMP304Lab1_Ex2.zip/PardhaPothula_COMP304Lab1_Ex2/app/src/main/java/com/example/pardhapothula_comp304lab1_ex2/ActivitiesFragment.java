package com.example.pardhapothula_comp304lab1_ex2;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class ActivitiesFragment extends Fragment {


    public ActivitiesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_activities, container, false);
        final ListView listView =(ListView) view.findViewById(R.id.listView);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                            @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                 {
                        //String name=listView.getItemAtPosition(position).toString();
                        if(position==0)
                        {
                            Intent intent=new Intent(getActivity(),DisplayAIActivity.class);
                            intent.putExtra("name","AIActivity");
                            startActivity(intent);

                        }
                        else if(position==1)
                        {
                            Intent intent=new Intent(getActivity(),DisplayVRActivity.class);
                            intent.putExtra("name","VRActivity");
                            startActivity(intent);
                        }
                 }
                   }
        );
        return view;
    }

}
