package com.example.pardhapothula_comp304lab1_ex2;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    DisplayFragment displayFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.displayText);
        FragmentManager fragmentManager=getSupportFragmentManager();
        displayFragment=(DisplayFragment)fragmentManager.findFragmentById(R.id.fragmentDisplay);
        fragmentManager.beginTransaction();
        String data="Main Activity:\n onCreate executed\n";
        Toast.makeText(getApplicationContext(), "onCreate", Toast.LENGTH_SHORT).show();
        displayFragment.display(data);

    }
    public void onStart()
    {
        super.onStart();
        String data="onStart executed\n";
        Toast.makeText(getApplicationContext(), "onStart", Toast.LENGTH_SHORT).show();
        displayFragment.display(data);
    }
    public void onStop()
    {
        super.onStop();
        String data="onStop executed\n";
        displayFragment.display(data);
    }
    public void onDestroy()
    {
        super.onDestroy();
        String data="onDestroy executed\n";
        displayFragment.display(data);
    }
}
