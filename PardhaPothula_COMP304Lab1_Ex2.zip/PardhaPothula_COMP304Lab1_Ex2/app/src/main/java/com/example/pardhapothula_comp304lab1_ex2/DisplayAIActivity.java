package com.example.pardhapothula_comp304lab1_ex2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DisplayAIActivity extends AppCompatActivity {
TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_ai);
        textView = findViewById(R.id.textViewAI);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            textView.append(bundle.getString("name")+"\n");
        }
        Toast.makeText(getApplicationContext(), "onCreate", Toast.LENGTH_SHORT).show();

        textView.append("onCreate executed\n");
    }
        public void onStart()
        {
            super.onStart();
            Toast.makeText(getApplicationContext(), "onStart", Toast.LENGTH_SHORT).show();
            textView.append("onStart executed\n");
        }
        public  void onStop()
        {
            super.onStop();
            Toast.makeText(getApplicationContext(), "onStop", Toast.LENGTH_SHORT).show();
            textView.append("onStop executed\n");
        }
        public  void onDestroy()
        {
            super.onDestroy();

            textView.append("onDestroy executed\n");
        }
    }

