package com.example.pardhapothula_comp304_000_hands_on_test1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    private RadioGroup rbgp1;
private RadioButton rb1,rb2,rb3,rb4,rb5,rb6,rb7;
Intent intent;
 public static String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rbgp1=findViewById(R.id.rbg1);
        rb1=findViewById(R.id.rbtn1);
        rb2=findViewById(R.id.rbtn2);
        rb3=findViewById(R.id.rbtn3);
        rb4=findViewById(R.id.rbtn4);
        rb5=findViewById(R.id.rbtn5);
        rb6=findViewById(R.id.rbtn6);
        rb7=findViewById(R.id.rbtn7);
        rbgp1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(rb1.isChecked())
                {
                    name=rb1.getText().toString();
                    intent=new Intent(getApplicationContext(),Message.class);
                    startActivity(intent);
                }
                if(rb2.isChecked())
                {
                    name=rb2.getText().toString();
                    intent=new Intent(getApplicationContext(),Message.class);
                    startActivity(intent);
                }
                if(rb3.isChecked())
                {
                    name=rb3.getText().toString();
                    intent=new Intent(getApplicationContext(),Message.class);
                    startActivity(intent);
                }
                if(rb4.isChecked())
                {
                    name=rb4.getText().toString();
                    intent=new Intent(getApplicationContext(),Message.class);
                    startActivity(intent);
                }
                if(rb5.isChecked())
                {
                    name=rb5.getText().toString();
                    intent=new Intent(getApplicationContext(),Message.class);
                    startActivity(intent);
                }
                if(rb6.isChecked())
                {
                    name=rb6.getText().toString();
                    intent=new Intent(getApplicationContext(),Message.class);
                    startActivity(intent);
                }
                if(rb7.isChecked())
                {
                    name=rb7.getText().toString();
                    intent=new Intent(getApplicationContext(),Message.class);
                    startActivity(intent);
                }
            }
        });

    }
}
