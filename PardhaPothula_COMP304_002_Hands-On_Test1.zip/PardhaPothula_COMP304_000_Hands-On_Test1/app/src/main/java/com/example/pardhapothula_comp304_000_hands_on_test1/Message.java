package com.example.pardhapothula_comp304_000_hands_on_test1;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class Message extends AppCompatActivity {


    private int startx = 10;
    private int starty = 10;
    private int endx=300;
    private int endy=300;
    EditText editText;

    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        setTitle(MainActivity.name);
        editText=findViewById(R.id.textEnter);

        button=findViewById(R.id.btnSend);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Message : "+editText.getText(), Toast.LENGTH_SHORT ).show();
            }
        });



    }
}
