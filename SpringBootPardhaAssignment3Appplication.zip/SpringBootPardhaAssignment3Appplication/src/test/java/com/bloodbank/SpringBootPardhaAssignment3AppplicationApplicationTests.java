package com.bloodbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPardhaAssignment3AppplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
