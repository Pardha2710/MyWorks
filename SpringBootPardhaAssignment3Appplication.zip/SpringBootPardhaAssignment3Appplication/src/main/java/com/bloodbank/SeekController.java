package com.bloodbank;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bloodbank.model.Seeker;

@Controller
public class SeekController {
	
private static ArrayList<Seeker> seekersList = new ArrayList<Seeker>();
	
	@RequestMapping("/")
    public String home()
    {
        return "index";
    }
    

    @RequestMapping(value = "/display", method = RequestMethod.POST)
    public ModelAndView saveSeeker(@ModelAttribute Seeker seeker)
    {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("seekerinfo");
        seekersList.add(seeker);
        mv.addObject("seekersList", seekersList);
        return mv;
    }
    
   
    
    
    
    

}
