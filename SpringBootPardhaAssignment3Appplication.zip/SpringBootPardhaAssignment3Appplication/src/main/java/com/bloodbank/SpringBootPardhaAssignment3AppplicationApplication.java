package com.bloodbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPardhaAssignment3AppplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPardhaAssignment3AppplicationApplication.class, args);
		System.out.println("SpringBootPardhaAssignment3AppplicationApplication REST Started");
	}

}
